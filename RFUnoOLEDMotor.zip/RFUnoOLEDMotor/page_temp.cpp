#include <avr/pgmspace.h>
#include "max6675.h"
#include "display.h"
#include "page_temp.h"
#include "seven.h"
#include "hexutil.h"

extern "C" void getDecStr (char* str, uint8_t len, uint32_t val);
extern uint8_t* str;

void temp_header()
{
    display_clear;

    display_font_start(0,0);
	  display_print_P(PSTR("TEMPERATURE   Celsius"));

}
void temp_periodic(){

  uint32_t thermo = thermo_read();
  unsigned int t = thermo>>5;
		  
  getDecStr(str,4,t);
  
          
  if(!thermo_good(thermo)) {
     
     clear_pos(DPOS4);
     clear_pos(DPOS3);
     clear_pos(DPOS2);
     clear_pos(DPOS1);
     clear_pos(DPOS0);

     seven_disp(DPOS4,255);
     seven_disp(DPOS3,255);
     seven_disp(DPOS2,255);
     seven_disp(DPOS1,255);
     seven_disp(DPOS0,255);

}
  else {
		    
    uint32_t packed = bin2bcd(t);
    
	  clear_pos(DPOS1);
	  seven_disp(POS1,packed);

    clear_pos(DPOS2);
	  seven_disp(POS2,packed>>4);

    clear_pos(DPOS3);
	  seven_disp(POS3,packed>>8);

    clear_pos(DPOS4);
	  seven_disp(POS4,packed>>12);

    //big degree sign
    seven_disp(POS0,10);
            
  }//else

}
