#include<Wire.h>

#define I2C_WRITE 0x00

void i2c_setup(){
  Wire.begin();
}

void i2c_write(unsigned char d){
  Wire.write(d);
}

void i2c_start_wait(unsigned char a){
  Wire.beginTransmission(a>>1);
}

void i2c_stop(){
  Wire.endTransmission();
}
