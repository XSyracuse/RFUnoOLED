#ifndef _CONFIG_H_INCLUDED_
#define _CONFIG_H_INCLUDED_


#define MAX6675_CS 10
//#define NOARDUINO

#endif
