#ifndef _PAGE_TEMP_H_
#define _PAGE_TEMP_H_




void temp_header();
void temp_periodic();



#endif
