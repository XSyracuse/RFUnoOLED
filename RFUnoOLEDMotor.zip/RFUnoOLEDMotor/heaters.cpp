/** \file
  \brief Manage heaters, including PID and PWM.
  Code for heater_init() and heater_set() is in the platform dependant include
  file and should pass six test cases when operating the heater via M106, temp
  sensors disabled:
   - PWM used on PWM-able pin, not inverted.
   - PWM pin used as on/off pin, not inverted.
   - Non-PWM-able pin, not inverted.
   - The three above, but inverted.
  In each test it should pass these tests:
   - Heater full on with M106 S255.
   - Heater full off with M106 S0.
   - Heater 10% on with M106 S25 on PWM pins.
   - Heater full off after reset, power supply turned on by other means.
   - For testing the inverted cases it's OK to check for behaving the opposite
     of the M106 command.
*/



/**
  \var heaters_pid
  \brief this struct holds the heater PID factors
  PID is a fascinating way to control any closed loop control, combining the error (P), cumulative error (I) and rate at which we're approacing the setpoint (D) in such a way that when correctly tuned, the system will achieve target temperature quickly and with little to no overshoot
  At every sample, we calculate \f$OUT = k_P (S - T) + k_I \int (S - T) + k_D \frac{dT}{dt}\f$ where S is setpoint and T is temperature.
  The three factors kP, kI, kD are chosen to give the desired behaviour given the dynamics of the system.
  See http://www.embedded.com/design/prototyping-and-development/4211211/PID-without-a-PhD for the full story
*/

#include "heaters.h"

struct {
  int32_t           p_factor; ///< scaled P factor: mibicounts/qc
  int32_t           i_factor; ///< scaled I factor: mibicounts/(qC*qs)
  int32_t           d_factor; ///< scaled D factor: mibicounts/(qc/(TH_COUNT*qs))
  int16_t           i_limit;  ///< scaled I limit, such that \f$-i_{limit} < i_{factor} < i_{limit}\f$
} heaters_pid[NUM_HEATERS];

#ifdef EECONFIG
/// this lives in the eeprom so we can save our PID settings for each heater
typedef struct {
  int32_t   EE_p_factor;
  int32_t   EE_i_factor;
  int32_t   EE_d_factor;
  int16_t   EE_i_limit;
  uint16_t  crc; ///< crc so we can use defaults if eeprom data is invalid
} EE_factor;

EE_factor EEMEM EE_factors[NUM_HEATERS];
#endif /* EECONFIG */


heater_runtime_t heaters_runtime[NUM_HEATERS];
soft_pwm_runtime_t soft_pwm_runtime[NUM_HEATERS];

/** Inititalise PID data structures.
  \param i Index of the heater to initialise by Teacup numbering.
*/
void pid_init() {
  uint8_t i;

  for (i = 0; i < NUM_HEATERS; i++) {


    #ifndef BANG_BANG
      {
        heaters_pid[i].p_factor = DEFAULT_P;
        heaters_pid[i].i_factor = DEFAULT_I;
        heaters_pid[i].d_factor = DEFAULT_D;
        heaters_pid[i].i_limit = DEFAULT_I_LIMIT;
      }
    #endif /* BANG_BANG */
  }
}

/** \brief run heater PID algorithm
  \param h which heater we're running the loop for
  \param type which temp sensor type this heater is attached to
  \param current_temp the temperature that the associated temp sensor is reporting
  \param target_temp the temperature we're trying to achieve
*/
void heater_tick(heater_t h, temp_type_t type, uint16_t current_temp, uint16_t target_temp) {
  // Static, so it's not mandatory to calculate a new value, see BANG_BANG.
  static uint8_t pid_output;

 
  int16_t   heater_p;
  int16_t   heater_d;
  int16_t   t_error = target_temp - current_temp;
 

  if (h >= NUM_HEATERS)
    return;

  if (target_temp == 0) {
    heater_set(h, 0);
    return;
  }

  
    heaters_runtime[h].temp_history[heaters_runtime[h].temp_history_pointer++] = current_temp;
    heaters_runtime[h].temp_history_pointer &= (TH_COUNT - 1);

    // PID stuff
    // proportional
    heater_p = t_error; // Units: qC where 4qC=1C

    // integral
    heaters_runtime[h].heater_i += t_error;  // Units: qC*qs where 16qC*qs=1C*s
    // prevent integrator wind-up
    if (heaters_runtime[h].heater_i > heaters_pid[h].i_limit)
      heaters_runtime[h].heater_i = heaters_pid[h].i_limit;
    else if (heaters_runtime[h].heater_i < -heaters_pid[h].i_limit)
      heaters_runtime[h].heater_i = -heaters_pid[h].i_limit;

    // derivative.  Units: qC/(TH_COUNT*qs) where 1C/s=TH_COUNT*4qC/4qs=8qC/qs)
    // note: D follows temp rather than error so there's no large derivative when the target changes
    heater_d = heaters_runtime[h].temp_history[heaters_runtime[h].temp_history_pointer] - current_temp;

    // combine factors
    int32_t pid_output_intermed = ( // Units: counts
                     (
                    (((int32_t) heater_p) * heaters_pid[h].p_factor) +
                    (((int32_t) heaters_runtime[h].heater_i) * heaters_pid[h].i_factor) +
                    (((int32_t) heater_d) * heaters_pid[h].d_factor)
                    ) / PID_SCALE
                     );

    // rebase and limit factors
    if (pid_output_intermed > 255) {
      if (t_error > 0)
        heaters_runtime[h].heater_i -= t_error; // un-integrate
      pid_output = 255;
    }
    else if (pid_output_intermed < 0) {
      if (t_error < 0)
        heaters_runtime[h].heater_i -= t_error; // un-integrate
      pid_output = 0;
    }
    else
      pid_output = pid_output_intermed & 0xFF;

    
  heater_set(h, pid_output);
}

/** \brief software PWM routine
*/

void heater_soft_pwm(heater_t index) {
  if (software_pwm_needed) {
    int16_t pwm;
    pwm = heaters_runtime[index].heater_output;

    // full off? then put it just off
    if (pwm == 0) {
      do_heater(index, 0);
      return;
    }

    // here we are doing a small trick. normally this is
    // sd_accu += pwm - sd_dir, where sd_dir is 255 or 0.
    // here we scale the (sd_dir) -part with the max_value.
    // max_value is precalculated with 255 * 100 / max_value(%).
    // so we get a smooth PWM also for downscaled heaters. the "pwm"-value
    // is from 0 to 255 in any case, but the sd_accu becomes bigger with
    // smaller max_values.
    soft_pwm_runtime[index].sd_accu += pwm - soft_pwm_runtime[index].sd_dir;

    if (soft_pwm_runtime[index].sd_accu > 0) {
      soft_pwm_runtime[index].sd_dir = heaters[index].max_value;
      do_heater(index, 255);
    }
    else {
      soft_pwm_runtime[index].sd_dir = 0;
      do_heater(index, 0);
    }
  }
}

/**
  Called every 10ms from clock.c. Tick the softPWM procedure when the heater needs it.
*/
void soft_pwm_tick() {
  if (software_pwm_needed) {
    uint8_t i;
    for (i = 0; i < NUM_HEATERS; i++) {
      if (heaters[i].pwm_type == SOFTWARE_PWM)
        heater_soft_pwm(i);
    }
  }
}

/** \brief set heater value and execute it
*/
void heater_set(heater_t index, uint8_t value) {
  heaters_runtime[index].heater_output = value;
  //do_heater(index, value);
}

/** \brief check whether all heaters are off
*/
uint8_t heaters_all_zero() {
  uint8_t i;

  for (i = 0; i < NUM_HEATERS; i++) {
    if (heaters_runtime[i].heater_output)
      return 0;
  }
  return 255;
}

uint8_t heater_print(){
  
  return heaters_runtime[0].heater_output;

}

uint8_t heater_pin_value;
void do_heater(uint8_t index,uint8_t value)
{
  
  heater_pin_value=value;

}

uint8_t get_heater()
{
  return heater_pin_value;
}
