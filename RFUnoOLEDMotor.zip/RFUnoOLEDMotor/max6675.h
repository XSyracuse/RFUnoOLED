
#ifndef __MAX6675_H_INCLUDED
#define __MAX6675_H_INCLUDED


#include<stdint.h>

void init_max6675();
void enable_max_CS();
void disable_max_CS();
uint16_t thermo_read();
uint8_t thermo_good(uint16_t thermo);
uint16_t thermo_adjust(uint16_t thermo);

#endif
