#include"config.h"
#include"max6675.h"

#ifndef NOARDUINO
#include<Arduino.h>
#include<SPI.h>
#endif

#ifndef MAX6675_CS

#define MAX6675_PORT  PORTE
#define MAX6675_DDR   DDRE
#define MAX6675_CS    PE0

#endif

void init_max6675() {

    //CS is output

    #ifdef NOARDUINO
    
    MAX6675_DDR |= (1<<MAX6675_CS);
    
    #else
    
    pinMode(MAX6675_CS,OUTPUT);
   
    #endif

    disable_max_CS();
}

void enable_max_CS()
{
    #ifdef NOARDUINO
    MAX6675_PORT &= ~(1<<MAX6675_CS);
    #else
    digitalWrite(MAX6675_CS,LOW);
    #endif 
}

void disable_max_CS()
{
    #ifdef NOARDUINO
    MAX6675_PORT |= (1<<MAX6675_CS);
    #else
    digitalWrite(MAX6675_CS,HIGH);
    #endif 
}

// data bits D14-D3 are the temperature
// D2 is normally low and goes high when thermocouple open 
uint16_t thermo_read(){
 
    uint16_t thermo, thermo_h, thermo_l;

    //read 16 bits
    
   
    #ifdef NOARDUINO
    asm("nop");
    enable_max_CS();
    thermo_h = read_spi(0);
    thermo_l = read_spi(0);
    disable_max_CS();
     
    #else
    
    SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));

    enable_max_CS();
    thermo_h = SPI.transfer(0);
    thermo_l = SPI.transfer(0);
    disable_max_CS();
     
    SPI.endTransaction();
        
    #endif
   
    thermo = thermo_h<<8;
    thermo += thermo_l;
    return thermo;
		
}

uint8_t thermo_good(uint16_t thermo)
{
    if(thermo & 0x04){
        return 0;
    }

    return 1;
}
uint16_t thermo_adjust(uint16_t thermo)
{
    //14.2 fixed point
    //truncate to whole number 
    return (thermo>>5);
}
