#ifndef __GETDECSTR_H__
#define __GETDECSTR_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

void getDecStr (char* str, uint8_t len, uint32_t val);

#ifdef __cplusplus
}
#endif


#endif
