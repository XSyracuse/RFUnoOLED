#ifndef _TEMP_H_
#define _TEMP_H_

uint16_t temp_table_lookup(uint16_t temp, uint8_t sensor);

#endif
