

#include<stdint.h>
#include <avr/pgmspace.h>
#include "temp.h"

/** \file
	\brief Manage temperature sensors
  \note All temperatures are stored as 14.2 fixed point in Teacup, so we have
  a range of 0 - 16383.75 deg Celsius at a precision of 0.25 deg. That includes
  the thermistor table, which is why you can't copy and paste one from other
  firmwares which don't do this.
*/

#include "thermistortable.h"

uint16_t temp_table_lookup(uint16_t temp, uint8_t sensor) {

  uint8_t lo, hi;
  uint8_t table_num = 0;

  // Binary search for table value bigger than our target.
  //
  //   lo = index of highest entry less than target.
  //   hi = index of lowest entry greater than or equal to target.
  for (lo = 0, hi = NUMTEMPS - 1; hi - lo > 1; ) {
    uint8_t j = lo + (hi - lo) / 2 ;
    if (pgm_read_word(&(temptable[table_num][j][0])) >= temp)
      hi = j ;
    else
      lo = j ;
  }

  // Linear interpolation using pre-computed slope.
  // y = y₁ - (x - x₁) * d₁
  #define X1 pgm_read_word(&(temptable[table_num][hi][0]))
  #define Y1 pgm_read_word(&(temptable[table_num][hi][1]))
  #define D1 pgm_read_word(&(temptable[table_num][hi][2]))

  temp = Y1 - ((((int32_t)temp - X1) * D1 + (1 << 7)) >> 8);
  
  return temp;

}
