#ifndef __MOTOR_PARSE_H__
#define __MOTOR_PARSE_H__

#include <stdint.h>


void parse_motor(char *line);


#endif
